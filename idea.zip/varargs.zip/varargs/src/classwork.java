public class classwork {
   static  void fun(String... c){
        System.out.println("number of arguments: " + c.length);
        //using for each loop to display contents of a
        for (String i:c)
            System.out.println(i + " ");
        System.out.println();
    }
    //Driver code
    public static void main(String[] args){
        //calling the varargs method with
        //different number of parameters

        //for parameter
        fun("john  ");

        //no parameter
        fun();
    }
}
