public class classtest1 {
    //a method that takes variable
    //number of integer arguments
    static  void fun(int... a){
        System.out.println("number of arguments: " + a.length);
        //using for each loop to display contents of a
        for (int i:a)
            System.out.println(i + " ");
        System.out.println();
    }
    //Driver code
    public static void main(String[] args){
        //calling the varargs method with
        //different number of parameters
        //one parameter
        fun(100);

        //for parameter
        fun(1,2);

        //no parameter
        fun();
    }
}
