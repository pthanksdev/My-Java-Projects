package com.company;

public class Main {

    public static void main(String[] args) {
        try {
            int testArray[];
            testArray = new int[3];
            testArray[0] = 1;
            testArray[1] = 2;
            testArray[2] = 3;
            System.out.println(testArray[3]);
        }catch (IndexOutOfBoundsException er){
            System.out.println("an out of bound occured");
        }
        try {
            int x = 1/0;
            System.out.println(x);
        }catch (ArithmeticException er){
            System.out.println("This calculation is an error");
        }
    }
}
