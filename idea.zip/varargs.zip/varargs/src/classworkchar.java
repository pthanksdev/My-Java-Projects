public class classworkchar {
    static  void fun(char... w){
        System.out.println("number of arguments: " + w.length);
        //using for each loop to display contents of a
        for (char i:w)
            System.out.println(i + " ");
        System.out.println();
    }
    //Driver code
    public static void main(String[] args){
        //calling the varargs method with
        //different number of parameters

        //for parameter
        fun();

        //no parameter
        fun();
    }
}
