public class classworkb {
    static void fun(boolean... b) {
        System.out.println("number of arguments: " + b.length);
        //using for each loop to display contents of a
        for (boolean i : b)
            System.out.println(i + " ");
        System.out.println();
    }

    //Driver code
    public static void main(String[] args) {
        //calling the varargs method with
        //different number of parameters

        //for parameter
        fun(true);

        //no parameter
        fun(false);

    }
}
