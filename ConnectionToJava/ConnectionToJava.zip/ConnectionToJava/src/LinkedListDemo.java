import java.util.LinkedList;

public class LinkedListDemo {
    public static void main(String[] args){
        LinkedList<String> list = new LinkedList<>();
        list.add("NIGERIA");
        list.add("GHANA");
        list.add("NIGER");
        list.addFirst("MALI");
        list.addLast("CONGA");
        list.add(2,"ALGERIA");
        //list.remove(2);
        list.add("BUKINA FASO");
        System.out.print(list);
    }
}
